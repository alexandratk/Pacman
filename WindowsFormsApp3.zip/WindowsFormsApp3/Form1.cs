﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Pole Massive;
        Graphics graph;
        public string FirstStep;
        public string SecondStep;
        public int Live;
        public int Level;
        public int TwoTheard;
        Thread MyThread; //поток в которм вырисовывается поле
        public Form1(Pole massive)
        {
            Massive = massive;
            SecondStep = "";
            FirstStep = "";
            Live = 3;
            Level = 1;
            this.KeyDown += new KeyEventHandler(Form_KeyDown);
            this.Paint += new PaintEventHandler(Form1_Paint);
            InitializeComponent();
        }
        //обработка события рисования
        private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            graph = e.Graphics;
            PaintPoleFirst();
            MyThread = new Thread(new ThreadStart(PaintArr)); // запускаем поток
            graph = CreateGraphics();
        }
        //прорисовка номера уровни
        public void PaintLevel()
        {
             graph.FillRectangle(Brushes.Black, 570, 80, 800, 150);
             Pen pen = new Pen(Color.White, 3);
             graph.DrawLine(pen, 600, 120, 600, 90);
             graph.DrawLine(pen, 600, 120, 610, 120);
             //e
             graph.DrawLine(pen, 615, 120, 625, 120);
             graph.DrawLine(pen, 615, 112, 625, 112);
             graph.DrawLine(pen, 615, 104, 625, 104);
             graph.DrawLine(pen, 615, 104, 615, 120);
             //v
             graph.DrawLine(pen, 630, 103, 635, 121);
             graph.DrawLine(pen, 640, 103, 635, 121);
             //e
             graph.DrawLine(pen, 645, 120, 655, 120);
             graph.DrawLine(pen, 645, 112, 655, 112);
             graph.DrawLine(pen, 645, 104, 655, 104);
             graph.DrawLine(pen, 645, 104, 645, 120);
             //l
             graph.DrawLine(pen, 660, 120, 660, 90);
             graph.DrawLine(pen, 660, 120, 670, 120);
             if (Level == 1)
             {
                 graph.DrawLine(pen, 695, 122, 695, 90);
             }
             if (Level == 2)
             {
                 graph.DrawLine(pen, 695, 122, 695, 90);
                 graph.DrawLine(pen, 705, 122, 705, 90);
             }
             if (Level == 3)
             {
                 graph.DrawLine(pen, 690, 122, 690, 90);
                 graph.DrawLine(pen, 700, 122, 700, 90);
                 graph.DrawLine(pen, 710, 122, 710, 90);
             }
             if (Level == 4)
             {
                 graph.DrawLine(pen, 690, 122, 690, 90);
                 graph.DrawLine(pen, 695, 90, 700, 121);
                 graph.DrawLine(pen, 705, 90, 700, 121);
             }
             if (Level == 5)
             {
                 graph.DrawLine(pen, 690, 90, 695, 121);
                 graph.DrawLine(pen, 700, 90, 695, 121);
             }
        }
        //прорисовка всех компонентов поля
        public void PaintPoleFirst()
        {
            Pen pen = new Pen(Color.DarkBlue, 3);
            for (int i = 0; i < Live; i++)
            {
                graph.FillEllipse(Brushes.Yellow, 600 + 35 * i, 50, 15, 15);
            }
            PaintLevel();
            for (int i = 0; i <= Massive.n + 1; i++)
            {
                for (int j = 0; j <= Massive.m + 1; j++)
                {
                    if (Massive.pole[i, j].c == '#')
                    {
                        pen = new Pen(Color.DarkBlue, 2);
                        graph.DrawRectangle(pen, j * 20 + 2, i * 20 + 2, 17, 17);
                    }
                    if (Massive.pole[i, j].c == '·')
                    {
                        pen = new Pen(Color.Yellow, 3);
                        graph.DrawEllipse(pen, j * 20 + 9, i * 20 + 9, 1, 1);
                    }
                    if (Massive.pole[i, j].c == '*')
                    {
                        graph.FillEllipse(Brushes.Yellow, j * 20 + 4, i * 20 + 4, 12, 12);
                    }
                    if (Massive.pole[i, j].c == 'o')
                    {
                        graph.FillEllipse(Brushes.Yellow, j * 20, i * 20, 20, 20);
                    }
                    if (Massive.pole[i, j].c == 'A')
                    {
                        graph.FillEllipse(Brushes.Red, Massive.bot.r.y * 20, Massive.bot.r.x * 20, 20, 20);
                        graph.FillEllipse(Brushes.LightPink, Massive.bot.p.y * 20, Massive.bot.p.x * 20, 20, 20);
                        graph.FillEllipse(Brushes.LightSkyBlue, Massive.bot.b.y * 20, Massive.bot.b.x * 20, 20, 20);
                        graph.FillEllipse(Brushes.DarkOrange, Massive.bot.o.y * 20, Massive.bot.o.x * 20, 20, 20);
                    }
                    if (Massive.pole[i, j].c == '-')
                    {
                        pen = new Pen(Color.White, 5);
                        graph.DrawLine(pen, j * 20 + 1, i * 20 + 10, (j + 1) * 20 + 1, i * 20 + 10);
                    }
                }
            }
        }
        //вырисовка компонентов поля
        public void PaintPole()
        {
            Pen pen = new Pen(Color.Black, 3);
            graph.FillEllipse(Brushes.Yellow, Massive.pm.y * 20, Massive.pm.x * 20, 20, 20);
            if (Massive.SideMove == "Up" || Massive.SideMove == "W")
            {
                for (int i = 0; i < 3; i++)
                {
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 + i*2, Massive.pm.x * 20);
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 - i*2, Massive.pm.x * 20);
                }
            }
            if (Massive.SideMove == "Down" || Massive.SideMove == "S")
            {
                for (int i = 0; i < 3; i++)
                {
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 + i * 2, Massive.pm.x * 20 + 20);
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 - i * 2, Massive.pm.x * 20 + 20);
                }
            }
            if (Massive.SideMove == "Right" || Massive.SideMove == "D")
            {
                for (int i = 0; i < 3; i++)
                {
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 20, Massive.pm.x * 20 + 10 + i * 2);
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 20, Massive.pm.x * 20 + 10 - i * 2);
                }
            }
            if (Massive.SideMove == "Left" || Massive.SideMove == "A")
            {
                for (int i = 0; i < 3; i++)
                {
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20, Massive.pm.x * 20 + 10 + i * 2);
                    graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20, Massive.pm.x * 20 + 10 - i * 2);
                }
            }
            pen = new Pen(Color.DarkBlue, 3);
            if (Massive.bot.r.sost < 0)
            {
                graph.FillEllipse(Brushes.DarkBlue, Massive.bot.r.y * 20, Massive.bot.r.x * 20, 20, 20);
            }
            else
            {
                graph.FillEllipse(Brushes.Red, Massive.bot.r.y * 20, Massive.bot.r.x * 20, 20, 20);
            }
            if (Massive.bot.p.sost < 0)
            {
                graph.FillEllipse(Brushes.DarkBlue, Massive.bot.p.y * 20, Massive.bot.p.x * 20, 20, 20);
            }
            else
            {
                graph.FillEllipse(Brushes.LightPink, Massive.bot.p.y * 20, Massive.bot.p.x * 20, 20, 20);
            }
            if (Massive.bot.b.sost < 0)
            {
                graph.FillEllipse(Brushes.DarkBlue, Massive.bot.b.y * 20, Massive.bot.b.x * 20, 20, 20);
            }
            else
            {
                graph.FillEllipse(Brushes.LightSkyBlue, Massive.bot.b.y * 20, Massive.bot.b.x * 20, 20, 20);
            }
            if (Massive.bot.o.sost < 0)
            {
                graph.FillEllipse(Brushes.DarkBlue, Massive.bot.o.y * 20, Massive.bot.o.x * 20, 20, 20);
            }
            else
            {
                graph.FillEllipse(Brushes.DarkOrange, Massive.bot.o.y * 20, Massive.bot.o.x * 20, 20, 20);
            }
            for (int i = 0; i <= Massive.n + 1; i++)
            {
                for (int j = 0; j <= Massive.m + 1; j++)
                {
                    if (Massive.pole[i, j].c == '-')
                    {
                        pen = new Pen(Color.White, 5);
                        graph.DrawLine(pen, j * 20, i * 20 + 10, (j + 1) * 20, i * 20 + 10);
                    }
                    if (Massive.pole[i, j].c == '·' && Massive.pole[i, j].cpast == 'A')
                    {
                        pen = new Pen(Color.Yellow, 3);
                        graph.DrawEllipse(pen, j * 20 + 9, i * 20 + 9, 1, 1);
                    }
                    if (Massive.pole[i, j].c == '*' && Massive.pole[i, j].cpast == 'A')
                    {
                        graph.FillEllipse(Brushes.Yellow, j * 20 + 4, i * 20 + 4, 12, 12);
                    }
                    if (Massive.pole[i, j].c == '-' && Massive.pole[i, j].cpast == 'A')
                    {
                        pen = new Pen(Color.White, 5);
                        graph.DrawLine(pen, j * 20, i * 20 + 10, (j + 1) * 20, i * 20 + 10);
                    }
                }
            }
        }
        //пользователь потерял жизнь
        public void PaintLoseLive()
        {
            Pen pen = new Pen(Color.Black, 3);
            for (int i = 0; i < 10; i++)
            {
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 + i, Massive.pm.x * 20);
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 10 - i, Massive.pm.x * 20);
                Thread.Sleep(30);
            }
            for (int i = 0; i < 20; i++)
            {
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20, Massive.pm.x * 20 + i);
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 20, Massive.pm.x * 20 + i);
                Thread.Sleep(30);
            }
            for (int i = 0; i <= 10; i++)
            {
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + i, Massive.pm.x * 20 + 20);
                graph.DrawLine(pen, (Massive.pm.y) * 20 + 10, Massive.pm.x * 20 + 10, Massive.pm.y * 20 + 20 - i, Massive.pm.x * 20 + 20);
                Thread.Sleep(30);
            }
            Thread.Sleep(400);
        }
        //пользователь прошел уровень
        public void PaintWinLevel()
        {
            graph.FillEllipse(Brushes.Yellow, Massive.bot.r.y * 20, Massive.bot.r.x * 20, 20, 20);
            graph.FillEllipse(Brushes.Yellow, Massive.bot.p.y * 20, Massive.bot.p.x * 20, 20, 20);
            graph.FillEllipse(Brushes.Yellow, Massive.bot.b.y * 20, Massive.bot.b.x * 20, 20, 20);
            graph.FillEllipse(Brushes.Yellow, Massive.bot.o.y * 20, Massive.bot.o.x * 20, 20, 20);
            graph.FillEllipse(Brushes.Yellow, Massive.pm.y * 20, Massive.pm.x * 20, 20, 20);
            Thread.Sleep(1000);
            PaintBlack();
            graph.FillRectangle(Brushes.Black, 0, 0, 700, 700);
            Thread.Sleep(400);
        }
        //закрашиваем прошлое положение героев черным(для анимации)
        public void PaintBlack()
        {
              graph.FillEllipse(Brushes.Black, Massive.pm.y * 20, Massive.pm.x * 20, 20, 20);
              graph.FillEllipse(Brushes.Black, Massive.bot.o.y * 20, Massive.bot.o.x * 20, 20, 20);
              graph.FillEllipse(Brushes.Black, Massive.bot.p.y * 20, Massive.bot.p.x * 20, 20, 20);
              graph.FillEllipse(Brushes.Black, Massive.bot.r.y * 20, Massive.bot.r.x * 20, 20, 20);
              graph.FillEllipse(Brushes.Black, Massive.bot.b.y * 20, Massive.bot.b.x * 20, 20, 20);
        }
        //пользователь роиграл все жизни
        public void GameOver()
        {
            graph.FillRectangle(Brushes.Black, 570, 80, 800, 150);
            Pen pen = new Pen(Color.White, 3);
            //o
            graph.DrawLine(pen, 580, 150, 580, 90);
            graph.DrawLine(pen, 600, 150, 600, 90);
            graph.DrawLine(pen, 580, 90, 600, 90);
            graph.DrawLine(pen, 600, 150, 580, 150);
            //h
            graph.DrawLine(pen, 610, 150, 610, 110);
            graph.DrawLine(pen, 610, 130, 625, 130);
            graph.DrawLine(pen, 625, 150, 625, 130);
            //,
            graph.DrawLine(pen, 635, 147, 635, 160);
            //n
            graph.DrawLine(pen, 655, 150, 655, 129);
            graph.DrawLine(pen, 655, 130, 670, 130);
            graph.DrawLine(pen, 670, 150, 670, 132);
            //o
            graph.DrawLine(pen, 680, 130, 695, 130);
            graph.DrawLine(pen, 680, 150, 695, 150);
            graph.DrawLine(pen, 695, 150, 695, 130);
            graph.DrawLine(pen, 679, 150, 679, 130);
            //!
            graph.DrawLine(pen, 710, 140, 710, 90);
            graph.DrawLine(pen, 710, 145, 710, 150);
        }
        //пользователь прошел все уровни
        public void Win()
        {
            for(int i = 0; i < 100; i++)
            {
                graph.FillEllipse(Brushes.Yellow, -200 + i * 10, 100, 300, 300);
                Thread.Sleep(100);
                graph.FillEllipse(Brushes.Black, -200 + i * 10, 100, 300, 300);
            }
        }
        //структура игры которую видит пользователь
        public void PaintArr()
        {
            Live = 3;
            Level = 1;
            while (Level <= 5)
            {
                int agrBot = 2;
                while (agrBot > 1 && Massive.colPoint != 0 && Massive.SideMove != "")
                {
                    PaintBlack();
                    Massive.KeyPressed(Massive.SideMove, 1);
                    agrBot = Massive.botPole(Massive.SideMove);
                    PaintPole();
                    Thread.Sleep(250);

                    if (Massive.KeyPressed(SecondStep, 0) == 3)
                    {
                        FirstStep = SecondStep;
                        SecondStep = "";
                        Massive.SideMove = FirstStep;
                    }
                }
                Thread.Sleep(200);
                if (Massive.SideMove != "")
                {
                    if (Massive.colPoint != 0)
                    {
                        Live--;
                        graph.FillEllipse(Brushes.Black, 600 + 35 * (Live), 50, 15, 15);
                        PaintLoseLive();
                        Thread.Sleep(500);
                        PaintBlack();
                        Massive.LoseLive();
                    }
                    else
                    {
                        Level++;
                        PaintWinLevel();
                        PaintBlack();
                        Massive.WinLevel();
                        Massive.level = Level;
                    }
                }
                FirstStep = "Right";
                SecondStep = "";
                if (Live == 0)
                {
                    GameOver();
                    Thread.Sleep(3000);
                    Massive.GameOver();
                    Live = 3;
                    Level = 1;
                    Massive.SideMove = "";
                }
                PaintPoleFirst();
                Thread.Sleep(1000);
            }
            Win();
        }
        //оброботка события от клавиатуры, нажатие клавиши
        private void Form_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (FirstStep == "")
            {
                MyThread.Start();
                FirstStep = "1";
            }
            if (Massive.KeyPressed(e.KeyCode.ToString(), 0) == 2)
            {
                SecondStep = e.KeyCode.ToString();
            }
            else
            {
                FirstStep = e.KeyCode.ToString();
            }
            Massive.SideMove = FirstStep;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
