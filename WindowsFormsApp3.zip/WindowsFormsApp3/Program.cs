﻿//при работе в vs 1.txt вставить в \ConsoleApp2\bin\Debug\netcoreapp3.1\ иначе поместить в одну папку с этим файлом
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
	public struct changeBot
	{
		public int t;
		public int dxt;
		public int dyt;
		public int a;
		public int b;

		public changeBot(int t, int dxt, int dyt, int a, int b)
		{
			this.t = t;
			this.dxt = dxt;
			this.dyt = dyt;
			this.a = a;
			this.b = b;
		}
	}
	//структура содержащая ссылки на оюъекты всех ботов
	public struct AllBot
	{
		public RedBot r;
		public PinkBot p;
		public BlueBot b;
		public OrangeBot o;
	}
	//абстрактный класс элемента поля
	public abstract class Element
	{
		public char c { set; get; }
		public char cpast { set; get; }
		public int x { set; get; }
		public int y { set; get; }

		public Element(int x, int y, char c)
		{
			this.c = c;
			if (c == 'A')
			{
				this.cpast = ' ';
			}
			this.cpast = c;
			this.x = x;
			this.y = y;
		}
	}
	//класс для не движущихся элементов поля
	public class ElPole : Element
	{
		public ElPole(int x, int y, char c) : base(x, y, c)
		{
		}
	}
	//класс порталов
	public class Portal : ElPole
	{
		public int x1 { set; get; }
		public int y1 { set; get; }
		public Portal(int x, int y, char c) : base(x, y, c)
		{
		}
		//добовлени второго входа портала
		public void sPortal(int x1, int y1)
		{
			this.x1 = x1;
			this.y1 = y1;
		}
	}
	//класс для движущихся элементов
	public abstract class Hero : Element
	{
		public int dx { set; get; }
		public int dy { set; get; }
		public int startx { set; get; }
		public int starty { set; get; }
		public Pole mas;
		public Hero(int x, int y, int startx, int starty, Pole m, char c) : base(x, y, c)
		{
			this.x = x;
			this.y = y;
			this.mas = m;
			this.dx = 0;
			this.dy = -1;
			this.startx = startx;
			this.starty = starty;
		}

		public virtual int Move(string key)
		{
			return 0;
		}
	}
	//класс пакмэна
	public class PacMan : Hero
	{
		public PacMan(int x, int y, int startx, int starty, Pole m) : base(x, y, startx, starty, m, 'o')
		{
		}
		//движение пакмэна
		public int Move(int i, int j, int flag)
		{
			if (mas.pole[i, j].c == '#' || mas.pole[i, j].c == '-')
			{
				return 2;
			}
			if (flag == 0)
			{
				return 3;
			}
			int rb = mas.moveEl(i, j, x, y);
			if (rb != 4 && rb != 1)
			{
				x = i;
				y = j;
			}
			return rb;
		}
		//изменение координат пакмэна
		public void changeXYPM(int x1, int y1)
		{
			x = x1;
			y = y1;
		}
	}
	//общий класс для ботов
	public abstract class Bot : Hero
	{
		public int sostx { set; get; }
		public int sosty { set; get; }
		public int color { set; get; }
		public int sost { set; get; }
		public int level { set; get; }

		public Bot(int x, int y, int colBot, int sost, int startx, int starty, int level, Pole m) : base(x, y, startx, starty, m, 'A')
		{
			this.sostx = 0;
			this.sosty = 0;
			this.color = colBot;
			this.sost = sost;
			this.level = level;
			this.mas = m;
		}
		//изменение координат бота
		public void changeXYBot(int x1, int y1, int c = 0)
		{
			this.x = x1;
			this.y = y1;
			sost = c;
		}
		//определение цвета бота и целевых точек в режиме испуга
		public void colorBot(int t)
		{
			//if (t == -1)
		//	{
		//		mas.pole[x, y].cf = ConsoleColor.Blue;
		//	}
			if (t == 0)
			{
				sostx = 2;
				sosty = mas.m - 2;
			}
			if (t == 1)
			{
				sostx = 2;
				sosty = 2;
			}
			if (t == 2)
			{
				sostx = mas.n - 2;
				sosty = mas.m - 2;
			}
			if (t == 3)
			{
				sostx = mas.n - 2;
				sosty = 2;
			}
		}
		//выход из режима испуга
		public void moveBot(string key)
		{
			if (sost == 0)
			{
				mas.bot.r.colorBot(0);
				mas.bot.p.colorBot(1);
				mas.bot.b.colorBot(2);
				mas.bot.o.colorBot(3);
				mas.bot.r.sost = 10 * (6 - mas.level) + 1;
				mas.bot.p.sost = 10 * (6 - mas.level) + 1;
				mas.bot.b.sost = 10 * (6 - mas.level) + 1;
				mas.bot.o.sost = 10 * (6 - mas.level) + 1;
			}
		}
		//движения в режиме испуга
		public changeBot escapeBot()
		{
			int t = 0;
			changeBot g;
			if (mas.pole[x - 1, y].c != '#' && mas.pole[x - 1, y].c != 'A')
			{
				t++;
			}
			if (mas.pole[x + 1, y].c != '#' && mas.pole[x + 1, y].c != 'A')
			{
				t++;
			}
			if (!((x == mas.portal.x && y - 1 == mas.portal.y) || (x == mas.portal.x1 && y - 1 == mas.portal.y1)))
			{
				if (mas.pole[x, y - 1].c != '#' && mas.pole[x, y - 1].c != 'A')
				{
					t++;
				}
			}
			if (!((x == mas.portal.x && y + 1 == mas.portal.y) || (x == mas.portal.x1 && y + 1 == mas.portal.y1)))
			{
				if (mas.pole[x, y + 1].c != '#' && mas.pole[x, y + 1].c != 'A')
				{
					t++;
				}
			}
			if (t == 1)
			{
				g = new changeBot(t, -dx, -dy, x - dx, y - dy);
				return g;
			}
			else
			{
				if (mas.pole[x + 1, y].c != '#' && dx != -1)
				{
					g = new changeBot(t, 1, 0, x + 1, y);
					return g;
				}
				if (mas.pole[x - 1, y].c != '#' && dx != 1)
				{
					g = new changeBot(t, -1, 0, x - 1, y);
					return g;
				}
				if (mas.pole[x, y - 1].c != '#' && dy != 1)
				{
					g = new changeBot(t, 0, -1, x, y - 1);
					return g;
				}
				if (mas.pole[x, y + 1].c != '#' && dy != -1)
				{
					g = new changeBot(t, 0, 1, x, y + 1);
					return g;
				}
			}
			changeBot gg = new changeBot(t, 0, 0, x, y);
			return gg;
		}
		//поиск возможных путей движения для бота
		public changeBot change(int xp, int yp)
		{
			int t = 300000;
			int dxt = 0;
			int dyt = 0;
			int a = 0, b = 0;
			if (mas.pole[x - 1, y].c != '#' && mas.pole[x - 1, y].c != 'A' && ((x - dx != x - 1) || (y - dy != y)))
			{
				if (t > (x - 1 - xp) * (x - 1 - xp) + (y - yp) * (y - yp))
				{
					t = (x - 1 - xp) * (x - 1 - xp) + (y - yp) * (y - yp);
					a = x - 1;
					b = y;
					dxt = -1;
					dyt = 0;
				}
			}
			if (mas.pole[x + 1, y].c != '#' && mas.pole[x + 1, y].c != 'A' && ((x - dx != x + 1) || (y - dy != y)))
			{
				if (t > (x + 1 - xp) * (x + 1 - xp) + (y - yp) * (y - yp))
				{
					t = (x + 1 - xp) * (x + 1 - xp) + (y - yp) * (y - yp);
					a = x + 1;
					b = y;
					dxt = 1;
					dyt = 0;
				}
			}
			if (mas.pole[x, y - 1].c != '#' && mas.pole[x, y - 1].c != 'A' && ((x - dx != x) || (y - dy != y - 1)))
			{
				if (t > (x - xp) * (x - xp) + (y - 1 - yp) * (y - 1 - yp))
				{
					t = (x - xp) * (x - xp) + (y - 1 - yp) * (y - 1 - yp);
					a = x;
					b = y - 1;
					dxt = 0;
					dyt = -1;
				}
			}
			if (mas.pole[x, y + 1].c != '#' && mas.pole[x, y + 1].c != 'A' && ((x - dx != x) || (y - dy != y + 1)))
			{
				if (t > (x - xp) * (x - xp) + (y + 1 - yp) * (y + 1 - yp))
				{
					t = (x - xp) * (x - xp) + (y + 1 - yp) * (y + 1 - yp);
					a = x;
					b = y + 1;
					dxt = 0;
					dyt = 1;
				}
			}
			changeBot g = new changeBot(t, dxt, dyt, a, b);
			return g;
		}
	}
	//класс для красного бота
	public class RedBot : Bot
	{
		public RedBot(int x, int y, int colBot, int sost, int startx, int starty, int level, Pole m) : base(x, y, colBot, sost, startx, starty, level, m)
		{
		}
		//движение красного бота
		public override int Move(string key)
		{
			moveBot(key);
			int t = 300000;
			int dxt = 0;
			int dyt = 0;
			int a = 0, b = 0;
			changeBot g;
			if (sost == -10 * (6 - mas.level) || sost == 0 || sost == 10 * (6 - mas.level))
			{
				dx = -dx;
				dy = -dy;
			}
			if (sost < 0)
			{
				g = escapeBot();
				t = g.t;
				dxt = g.dxt;
				dyt = g.dyt;
				a = g.a;
				b = g.b;
				if (mas.moveEl(a, b, x, y, color) != 4)
				{
					x = a;
					y = b;
				}
				dx = dxt;
				dy = dyt;
				sost++;
				return 3;
			}
			if (sost < 10 * (6 - mas.level))
			{
				g = change(sostx, sosty);
				sost++;
			}
			else
			{
				if (sost == 90)
				{
					sost = 0;
				}
				sost++;
				g = change(mas.pm.x, mas.pm.y);
			}
			t = g.t;
			dxt = g.dxt;
			dyt = g.dyt;
			a = g.a;
			b = g.b;
			if (t == 300000)
			{
				a = x - dx;
				b = y - dy;
				dxt = -dx;
				dyt = -dy;
			}
			int rb = mas.moveEl(a, b, x, y, color);
			if (rb >= 4 || rb == 1)
			{
				if (rb == 4)
				{
					dx = -dx;
					dy = -dy;
				}
			}
			else
			{
				x = a;
				y = b;
				dx = dxt;
				dy = dyt;
			}
			return rb;
		}

	}
	//класс для розового бота
	public class PinkBot : Bot
	{
		public PinkBot(int x, int y, int colBot, int sost, int startx, int starty, int level, Pole m) : base(x, y, colBot, sost, startx, starty, level, m)
		{
		}
		//движение розового бота
		public override int Move(string key)
		{
			moveBot(key);
			int t = 300000;
			int dxt = 0;
			int dyt = 0;
			int a = 0, b = 0;
			int xp = 0, yp = 0;
			if (key == "Up" || key == "W")
			{
				xp = mas.pm.x;
				yp = mas.pm.y - 4;
			}
			if (key == "Down" || key == "D")
			{
				xp = mas.pm.x;
				yp = mas.pm.y + 4;
			}
			if (key == "Left" || key == "A")
			{
				xp = mas.pm.x - 4;
				yp = mas.pm.y;
			}
			if (key == "Right" || key == "D")
			{
				xp = mas.pm.x + 4;
				yp = mas.pm.y;
			}
			changeBot g;
			if (sost == -10 * (6 - mas.level) || sost == 0 || sost == 10 * (6 - mas.level))
			{
				dx = -dx;
				dy = -dy;
			}
			if (sost < 0)
			{
				g = escapeBot();
				t = g.t;
				dxt = g.dxt;
				dyt = g.dyt;
				a = g.a;
				b = g.b;
				if (mas.moveEl(a, b, x, y, color) != 4)
				{
					x = a;
					y = b;
				}
				dx = dxt;
				dy = dyt;
				sost++;
				return 3;
			}

			if (sost < 10 * (6 - mas.level))
			{
				g = change(sostx, sosty);
				sost++;
			}
			else
			{
				if (sost == 90)
				{
					sost = 0;
				}
				sost++;
				g = change(xp, yp);
			}
			t = g.t;
			dxt = g.dxt;
			dyt = g.dyt;
			a = g.a;
			b = g.b;
			if (t == 300000)
			{
				a = x - dx;
				b = y - dy;
				dxt = -dx;
				dyt = -dy;
			}
			int rb = mas.moveEl(a, b, x, y, color);
			if (rb >= 4 || rb == 1)
			{
				if (rb == 4)
				{
					dx = -dx;
					dy = -dy;
				}
			}
			else
			{
				x = a;
				y = b;
				dx = dxt;
				dy = dyt;
			}
			return rb;
		}
	}
	//класс для синего бота
	public class BlueBot : Bot
	{
		public BlueBot(int x, int y, int colBot, int sost, int startx, int starty, int level, Pole m) : base(x, y, colBot, sost, startx, starty, level, m)
		{
		}
		//движение синего бота
		public override int Move(string key)
		{
			moveBot(key);
			int t = 300000;
			int dxt = 0;
			int dyt = 0;
			int a = 0, b = 0;
			int xp = 0, yp = 0;
			if (key == "Up" || key == "W")
			{
				xp = mas.pm.x;
				yp = mas.pm.y - 2;
			}
			if (key == "Down" || key == "S")
			{
				xp = mas.pm.x;
				yp = mas.pm.y + 2;
			}
			if (key == "Left" || key == "A")
			{
				xp = mas.pm.x - 2;
				yp = mas.pm.y;
			}
			if (key == "Right" || key == "D")
			{
				xp = mas.pm.x + 2;
				yp = mas.pm.y;
			}
			if (xp < mas.bot.r.x)
			{
				xp = xp - mas.bot.r.x;
			}
			else
			{
				xp = xp + mas.bot.r.x;
			}
			if (yp < mas.bot.r.y)
			{
				yp = yp - mas.bot.r.y;
			}
			else
			{
				yp = yp + mas.bot.r.y;
			}
			changeBot g;
			if (sost == -10 * (6 - mas.level) || sost == 0 || sost == 10 * (6 - mas.level))
			{
				dx = -dx;
				dy = -dy;
			}
			if (sost < 0)
			{
				g = escapeBot();
				t = g.t;
				dxt = g.dxt;
				dyt = g.dyt;
				a = g.a;
				b = g.b;
				if (mas.moveEl(a, b, x, y, color) != 4)
				{
					x = a;
					y = b;
				}
				dx = dxt;
				dy = dyt;
				sost++;
				return 3;
			}
			if (sost < 10 * (6 - mas.level))
			{
				g = change(sostx, sosty);
				sost++;
			}
			else
			{
				if (sost == 90)
				{
					sost = 0;
				}
				sost++;
				g = change(xp, yp);
			}
			t = g.t;
			dxt = g.dxt;
			dyt = g.dyt;
			a = g.a;
			b = g.b;
			if (t == 300000)
			{
				a = x - dx;
				b = y - dy;
				dxt = -dx;
				dyt = -dy;
			}
			int rb = mas.moveEl(a, b, x, y, color);
			if (rb >= 4 || rb == 1)
			{
				if (rb == 4)
				{
					dx = -dx;
					dy = -dy;
				}
			}
			else
			{
				x = a;
				y = b;
				dx = dxt;
				dy = dyt;
			}
			return rb;
		}
	}
	//класс для оранжевого бота
	public class OrangeBot : Bot
	{
		public OrangeBot(int x, int y, int colBot, int sost, int startx, int starty, int level, Pole m) : base(x, y, colBot, sost, startx, starty, level, m)
		{
		}
		//рекурсивная проверка наличия пакмэна в ближайших клетках
		public bool moveOrangeRecursion(int i, int j, int n)
		{
			if (n == 9)
			{
				return false;
			}
			if (mas.pole[i, j].c == 'o')
			{
				return true;
			}
			else
			{
				bool t = false;
				if (i + 1 <= mas.n + 1 && i + 1 >= 0 && j <= mas.m + 1 && j >= 0 && mas.pole[i + 1, j].c != '#' && moveOrangeRecursion(i + 1, j, n + 1) == true)
				{
					t = true;
				}
				if (i - 1 <= mas.n + 1 && i - 1 >= 0 && j <= mas.m + 1 && j >= 0 && mas.pole[i - 1, j].c != '#' && moveOrangeRecursion(i - 1, j, n + 1) == true)
				{
					t = true;
				}
				if (i <= mas.n + 1 && i >= 0 && j + 1 <= mas.m + 1 && j + 1 >= 0 && mas.pole[i, j + 1].c != '#' && moveOrangeRecursion(i, j + 1, n + 1) == true)
				{
					t = true;
				}
				if (i <= mas.n + 1 && i >= 0 && j - 1 <= mas.m + 1 && j - 1 >= 0 && mas.pole[i, j - 1].c != '#' && moveOrangeRecursion(i, j - 1, n + 1) == true)
				{
					t = true;
				}
				return t;
			}
		}
		//движение оранжевого бота
		public override int Move(string key)
		{
			moveBot(key);
			int t = 300000;
			int dxt = 0;
			int dyt = 0;
			int a = 0, b = 0;
			int xp = 0, yp = 0;
			if (moveOrangeRecursion(x, y, 1) == true)
			{
				xp = sostx;
				yp = sosty;
			}
			else
			{
				xp = mas.pm.x;
				yp = mas.pm.y;
			}
			changeBot g;
			if (sost == -10 * (6 - mas.level) || sost == 0 || sost == 10 * (6 - mas.level))
			{
				dx = -dx;
				dy = -dy;
			}
			if (sost < 0)
			{
				g = escapeBot();
				t = g.t;
				dxt = g.dxt;
				dyt = g.dyt;
				a = g.a;
				b = g.b;
				int rt = mas.moveEl(a, b, x, y, color);
				if (rt != 4)
				{
					x = a;
					y = b;
					dx = dxt;
					dy = dyt;
				}
				else
				{
					dx = -dx;
					dy = -dy;
				}
				sost++;
				return 3;
			}
			if (sost < 10 * (6 - mas.level))
			{
				g = change(sostx, sosty);
				sost++;
			}
			else
			{
				if (sost == 90)
				{
					sost = 0;
				}
				sost++;
				g = change(xp, yp);
			}
			t = g.t;
			dxt = g.dxt;
			dyt = g.dyt;
			a = g.a;
			b = g.b;
			if (t == 300000)
			{
				a = x - dx;
				b = y - dy;
				dxt = -dx;
				dyt = -dy;
			}
			int rb = mas.moveEl(a, b, x, y, color);
			if (rb >= 4 || rb == 1)
			{
				if (rb == 4)
				{
					dx = -dx;
					dy = -dy;
				}
			}
			else
			{
				x = a;
				y = b;
				dx = dxt;
				dy = dyt;
			}
			return rb;
		}
	}
	//класс поля
	public class Pole
	{
		public ElPole[,] pole;
		public int n { set; get; }
		public int m { set; get; }
		public int level { set; get; }
		public int live { set; get; }
		public PacMan pm;
		public AllBot bot;
		public int colBot { set; get; }
		public int colPoint { set; get; }
		public int startColPoint { set; get; }
		public Portal portal;
		int r { set; get; }
		public string SideMove;

		public Pole(string s, int level, int live)
		{
			colBot = 0;
			colPoint = 0;
			startColPoint = 0;
			this.level = level;
			this.live = live;
			bot = new AllBot();
			r = 1;
			CreatePole(s);
		}
		//создания забора вокруг поля
		public void zabor()
		{
			for (int i = 0; i < n + 2; i++)
			{
				for (int j = 0; j < m + 2; j++)
				{
					pole[i, j] = new ElPole(i, j, '#');
				}
			}
		}
		//создание дыры в заборе на месте портала
		public void portalWay(int x, int y, int t)
		{
			pole[x, y] = new ElPole(x, y, ' ');
			if (y == m)
			{
				pole[x, y + 1] = new ElPole(x, y + 1, ' ');
				if (t == 0)
				{
					portal.y = y + 1;
				}
				else
				{
					portal.y1 = y + 1;
				}
			}
			if (y == 1)
			{
				pole[x, y - 1] = new ElPole(x, y - 1, ' ');
				if (t == 0)
				{
					portal.y = y - 1;
				}
				else
				{
					portal.y1 = y - 1;
				}
			}
			if (x == n)
			{
				pole[x + 1, y] = new ElPole(x + 1, y, ' ');
				if (t == 0)
				{
					portal.x = x + 1;
				}
				else
				{
					portal.x1 = x + 1;
				}
			}
			if (x == 1)
			{
				pole[x - 1, y] = new ElPole(x - 1, y, ' ');
				if (t == 0)
				{
					portal.x = x - 1;
				}
				else
				{
					portal.x1 = x - 1;
				}
			}
		}
		//считывание поля из файла
		public void CreatePole(string s)
		{
			StreamReader sr = new StreamReader(s);
			String line = sr.ReadLine();
			this.n = Convert.ToInt32(line);
			line = sr.ReadLine();
			this.m = Convert.ToInt32(line);
			pole = new ElPole[n + 2, m + 2];
			int j = 1;
			zabor();
			while ((line = sr.ReadLine()) != null)
			{
				for (int i = 0; i < line.Length; i++)
				{
					pole[j, i + 1] = new ElPole(j, i + 1, line[i]);
					if (line[i] == 'o')
					{
						pole[j, i + 1].cpast = ' ';
						this.pm = new PacMan(j, i + 1, j, i + 1, this);
					}
					if (line[i] == '0')
					{
						pole[j, i + 1] = new ElPole(j, i + 1, ' ');
						portal = new Portal(j, i + 1, line[i]);
						portalWay(j, i + 1, 0);
					}
					if (line[i] == '1')
					{
						pole[j, i + 1] = new ElPole(j, i + 1, ' ');
						portal.sPortal(j, i + 1);
						portalWay(j, i + 1, 1);
					}
					if (line[i] == '·')
					{
						colPoint++;
						startColPoint++;
					}
					if (line[i] == 'A')
					{
						pole[j, i + 1].cpast = ' ';
						if (colBot == 0)
						{
							bot.r = new RedBot(j, i + 1, colBot, 1, j, i + 1, level, this);
							bot.r.colorBot(colBot);
						}
						if (colBot == 1)
						{
							bot.p = new PinkBot(j, i + 1, colBot, 1, j, i + 1, level, this);
							bot.p.colorBot(colBot);
						}
						if (colBot == 2)
						{
							bot.b = new BlueBot(j, i + 1, colBot, 1, j, i + 1, level, this);
							bot.b.colorBot(colBot);
						}
						if (colBot == 3)
						{
							bot.o = new OrangeBot(j, i + 1, colBot, 1, j, i + 1, level, this);
							bot.o.colorBot(colBot);
						}
						colBot++;
					}
				}
				j++;
			}
		}
		//пакмэн съедает бота или бот пакмэна
		public int eatBot(int x, int y, int x1, int y1)
		{
			if (bot.r.x == x1 && bot.r.y == y1 && bot.r.sost < 0)
			{
				bot.r.changeXYBot(bot.r.startx, bot.r.starty, 10 * (6 - level) + 1);
				pole[bot.r.startx, bot.r.starty].c = 'A';
				bot.r.colorBot(0);
				pole[x1, y1].c = pole[x1, y1].cpast;
				pm.changeXYPM(x, y);
				return 4;
			}
			else
			{
				if (bot.r.x == x1 && bot.r.y == y1)
				{
					return 1;
				}
			}
			if (bot.p.x == x1 && bot.p.y == y1 && bot.p.sost < 0)
			{
				bot.p.changeXYBot(bot.p.startx, bot.p.starty, 10 * (6 - level) + 1);
				pole[bot.p.startx, bot.p.starty].c = 'A';
				bot.p.colorBot(1);
				pole[x1, y1].c = pole[x1, y1].cpast;
				pm.changeXYPM(x, y);
				return 4;
			}
			else
			{
				if (bot.p.x == x1 && bot.p.y == y1)
				{
					return 1;
				}
			}
			if (bot.b.x == x1 && bot.b.y == y1 && bot.b.sost < 0)
			{
				bot.b.changeXYBot(bot.b.startx, bot.b.starty, 10 * (6 - level) + 1);
				pole[bot.b.startx, bot.b.starty].c = 'A';
				bot.b.colorBot(2);
				pole[x1, y1].c = pole[x1, y1].cpast;
				pm.changeXYPM(x, y);
				return 4;
			}
			else
			{
				if (bot.b.x == x1 && bot.b.y == y1)
				{
					return 1;
				}
			}
			if (bot.o.x == x1 && bot.o.y == y1 && bot.o.sost < 0)
			{
				bot.o.changeXYBot(bot.o.startx, bot.o.starty, 10 * (6 - level) + 1);
				pole[bot.o.startx, bot.o.starty].c = 'A';
				bot.o.colorBot(3);
				pole[x1, y1].c = pole[x1, y1].cpast;
				pm.changeXYPM(x, y);
				return 4;
			}
			else
			{
				if (bot.o.x == x1 && bot.o.y == y1)
				{
					return 1;
				}
			}
			return 4;
		}
		//пакмэн заходит в портал
		public void PMteleport(int x, int y, int x1, int y1)
		{
			int i, j;
			pole[x1, y1].c = ' ';
			if (x == portal.x && y == portal.y)
			{
				i = portal.x1;
				j = portal.y1 - 1;
			}
			else
			{
				i = portal.x;
				j = portal.y + 1;
			}
			pm.changeXYPM(i, j);
			pole[i, j].cpast = pole[i, j].c;
			pole[i, j].c = 'o';
		}
		//бот заходит в портал
		public void BOTteleport(int x, int y, int x1, int y1)
		{
			int i, j;
			pole[x1, y1].c = ' ';
			if (x == portal.x && y == portal.y)
			{
				i = portal.x1;
				j = portal.y1 - 1;
			}
			else
			{
				i = portal.x;
				j = portal.y + 1;
			}
			if (bot.r.x == x1 && bot.r.y == y1)
			{
				bot.r.changeXYBot(i, j, bot.r.sost + 1);
				pole[i, j].cpast = pole[i, j].c;
				pole[i, j].c = 'A';
				if (bot.r.sost < 0)
				{
					bot.r.colorBot(-1);
				}
				else
				{
					bot.r.colorBot(0);
				}
			}
			if (bot.p.x == x1 && bot.p.y == y1)
			{
				bot.p.changeXYBot(i, j, bot.p.sost + 1);
				pole[i, j].cpast = pole[i, j].c;
				pole[i, j].c = 'A';
				if (bot.p.sost < 0)
				{
					bot.p.colorBot(-1);
				}
				else
				{
					bot.p.colorBot(1);
				}
			}
			if (bot.b.x == x1 && bot.b.y == y1)
			{
				bot.b.changeXYBot(i, j, bot.b.sost + 1);
				pole[i, j].cpast = pole[i, j].c;
				pole[i, j].c = 'A';
				if (bot.b.sost < 0)
				{
					bot.b.colorBot(-1);
				}
				else
				{
					bot.b.colorBot(2);
				}
			}
			if (bot.o.x == x1 && bot.o.y == y1)
			{
				bot.o.changeXYBot(i, j, bot.o.sost + 1);
				pole[i, j].cpast = pole[i, j].c;
				pole[i, j].c = 'A';
				if (bot.o.sost < 0)
				{
					bot.o.colorBot(-1);
				}
				else
				{
					bot.o.colorBot(3);
				}
			}
		}
		//изменение положения элемента поля
		public int moveEl(int x, int y, int x1, int y1, int c = -1)
		{
			if (pole[x1, y1].c == 'A' && pole[x, y].c == 'o')
			{
				return (eatBot(x, y, x1, y1));
			}
			if (pole[x, y].c == 'A' && pole[x1, y1].c == 'o')
			{
				return (eatBot(x1, y1, x, y));
			}
			if (pole[x1, y1].c == 'o' && pole[x, y].c == '*')
			{
				bot.r.colorBot(-1);
				bot.r.sost = -10 * (6 - level);
				bot.p.colorBot(-1);
				bot.p.sost = -10 * (6 - level);
				bot.b.colorBot(-1);
				bot.b.sost = -10 * (6 - level);
				bot.o.colorBot(-1);
				bot.o.sost = -10 * (6 - level);
			}
			if ((pole[x1, y1].c == 'o' && x == portal.x && y == portal.y) || (pole[x1, y1].c == 'o' && x == portal.x1 && y == portal.y1))
			{
				PMteleport(x, y, x1, y1);
				return 4;
			}
			if ((pole[x1, y1].c == 'A' && x == portal.x && y == portal.y) || (pole[x1, y1].c == 'A' && x == portal.x1 && y == portal.y1))
			{
				BOTteleport(x, y, x1, y1);
				return 5;
			}
			if (pole[x1, y1].c == 'o')
			{
				if (pole[x, y].c == '·')
				{
					colPoint--;
				}
				pole[x, y] = pole[x1, y1];
				pole[x1, y1] = new ElPole(x1, y1, ' ');
				pm.changeXYPM(x, y);
				return 3;
			}
			if (pole[x1, y1].c == 'A' && pole[x, y].c == 'A')
			{
				return 4;
			}
			if (pole[x1, y1].c == 'A' && pole[x, y].c != '#')
			{
				pole[x1, y1].c = pole[x1, y1].cpast;
				pole[x1, y1].cpast = 'A';
				pole[x, y].cpast = pole[x, y].c;
				pole[x, y].c = 'A';
				return 3;
			}
			else
			{
				if (pole[x, y].c == '#')
					return 4;
			}
			return 3;

		}
		//управление пакмэном
		public int KeyPressed(string key, int flag)
		{
			int t = 6;
			if ((key == "Up" || key == "W") && t > 1)
			{
				t = pm.Move(pm.x - 1, pm.y, flag);
			}
			if ((key == "Down" || key == "S") && t > 1)
			{
				t = pm.Move(pm.x + 1, pm.y, flag);
			}
			if ((key == "Right" || key == "D") && t > 1)
			{
				t = pm.Move(pm.x, pm.y + 1, flag);
			}
			if ((key == "Left" || key == "A") && t > 1)
			{
				t = pm.Move(pm.x, pm.y - 1, flag);
			}
			return (afterKeyPressed(t));
		}
		//возможные последствия после перемещения пакмэна
		public int afterKeyPressed(int t)
		{
			if (t == 2)
			{
				return 2;
			}
			if (t == 6)
			{
				return 6;
			}
			if (t <= 1)
			{
				return 1;
			}
			else
			{
				return 3;
			}

		}
		//потеря жизни
		public void LoseLive()
		{
			startColPoint = colPoint;
			r = 0;
			live--;
			SideMove = "Right";
			pole[pm.x, pm.y].c = pole[pm.x, pm.y].cpast;
			pm.changeXYPM(pm.startx, pm.starty);
			pole[pm.x, pm.y].cpast = pole[pm.x, pm.y].c;
			pole[pm.x, pm.y].c = 'o';
			pole[bot.r.x, bot.r.y].c = pole[bot.r.x, bot.r.y].cpast;
			pole[bot.r.x, bot.r.y].cpast = 'A';
			bot.r.changeXYBot(bot.r.startx, bot.r.starty, 1);
			pole[bot.r.startx, bot.r.starty].c = 'A';
			bot.r.colorBot(0);
			pole[bot.p.x, bot.p.y].c = pole[bot.p.x, bot.p.y].cpast;
			pole[bot.p.x, bot.p.y].cpast = 'A';
			bot.p.changeXYBot(bot.p.startx, bot.p.starty, 1);
			pole[bot.p.startx, bot.p.starty].c = 'A';
			bot.p.colorBot(1);
			pole[bot.b.x, bot.b.y].c = pole[bot.b.x, bot.b.y].cpast;
			pole[bot.b.x, bot.b.y].cpast = 'A';
			bot.b.changeXYBot(bot.b.startx, bot.b.starty, 1);
			pole[bot.b.startx, bot.b.starty].c = 'A';
			bot.b.colorBot(2);
			pole[bot.o.x, bot.o.y].c = pole[bot.o.x, bot.o.y].cpast;
			pole[bot.o.x, bot.o.y].cpast = 'A';
			bot.o.changeXYBot(bot.o.startx, bot.o.starty, 1);
			pole[bot.o.startx, bot.o.starty].c = 'A';
			bot.o.colorBot(3);
		}
		//переход на следующий уровень
		public void WinLevel()
		{
			LoseLive();
			CreatePole("1.txt");
		}
		//перемещение бота
		public int botPole(string key)
		{
			int rb = 3;
			if (rb != 1 && r >= 1)
			{
				rb = bot.r.Move(key);
			}
			else
			{
				bot.r.sost++;
			}
			if (rb != 1 && r >= startColPoint / 6)
			{
				rb = bot.p.Move(key);
			}
			else
			{
				bot.p.sost++;
			}
			if (rb != 1 && r >= startColPoint / 6 * 2)
			{
				rb = bot.b.Move(key);
			}
			else
			{
				bot.b.sost++;
			}
			if (rb != 1 && r >= startColPoint / 6 * 3)
			{
				rb = bot.o.Move(key);
			}
			else
			{
				bot.o.sost++;
			}
			r++;
			return rb;
		}
		//потеряли все жизни
		public void GameOver()
		{
			colBot = 0;
			colPoint = 0;
			startColPoint = 0;
			level = 1;
			live = 3;
			bot = new AllBot();
			r = 1;
			CreatePole("1.txt");
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			int level = 1;
			int live = 3;
			Pole massive = new Pole("1.txt", level, live);
			Form1 FormMain = new Form1(massive);
			Application.Run(FormMain);
		}
	}
}